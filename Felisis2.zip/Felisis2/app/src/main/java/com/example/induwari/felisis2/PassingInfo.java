package com.example.induwari.felisis2;

/**
 * Created by Induwari on 4/02/2017.
 */

public class PassingInfo {
    public class PassingInfo extends AppCompatActivity {

        public string vegId = 0;
        public string vegName = '';
        public int vegWeight;
        int random = random();
        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.activity_main);
            Button correct = (Button) findViewByVegId(R.id.correct);
            Button other = (Button) findViewByVegId(R.id.other);
            Button newGame = (Button) findViewByVegId(R.id.newGame);
            TextView words = (TextView) findViewByVegId(R.id.words);


        }

        public Integer random (){
            int random = (int )(Math.random() * 5);
            return random;
        }

        private String list[] =
                {"Carrot", "Beatroot", "Beans", "Pumkin", "Potatoes", "Tomatoes"};

        public void clickedButton(View view) {
            TextView words = (TextView) findViewById(R.id.words);
            if (view.getId()== R.id.newGame)
            {
                words.setText(list[random]);
                score = 0;
                Log.i("amount", "amount = " + amount);
            }
            if (view.getId() == R.id.correct)
            {
                // set maybe new array so new textview does not give the same value
                words.setText(list[random]);
                score = score +1;
                Log.i("amount", "amount = " + score);
            }
            if (view.getId() == R.id.other)
            {
                // set maybe new array so new textview does not give the same value
                words.setText(list[random]);
                Log.i("amount", "amount = " + amount);
            }

        }
    }
}
